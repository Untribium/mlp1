function timestamp = ts()
    timestamp = ['[', datestr(now, 'HH:MM:SS'), ']'];
end